# Summary

# Checklist

- [ ] Added changelog entry
- [ ] Ran unit tests (`npm test`)

<!-- **For Braintree Developers only, don't forget:**
- [ ] Does this change require work to be done to the GraphQL API? If you have questions check with the GraphQL team.
- [ ] Add & Run integration tests -->
