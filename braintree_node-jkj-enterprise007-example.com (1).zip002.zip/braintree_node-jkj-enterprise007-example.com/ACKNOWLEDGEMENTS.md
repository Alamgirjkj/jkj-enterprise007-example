Acknowledgements
----------------

The Braintree SDK uses code from the following libraries:

* [chai](https://github.com/chaijs/chai), MIT License
* [dateformat](https://github.com/felixge/node-dateformat), MIT License
* [eslint](https://github.com/eslint/eslint), MIT License
* [eslint-config-braintree](https://github.com/braintree/eslint-config), MIT License
* [mocha](https://github.com/mochajs/mocha), MIT License
* [sinon](https://github.com/sinonjs/sinon), BSD License
* [wrap-promise](https://github.com/braintree/wrap-promise), MIT License
* [xml2js](https://github.com/Leonidas-from-XIV/node-xml2js), MIT License
